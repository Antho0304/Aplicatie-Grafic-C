﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace GraficTextInputWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnGenereaza_Click(object sender, RoutedEventArgs e)
        {
            // curățăm graficul vechi
            grafic.Series.Clear();

            try
            {
                // conversie din TextBox la array de double
                var valori = txtValori.Text
                    .Split(',')
                    .Select(v => double.Parse(v.Trim()))
                    .ToArray();

                // determinăm tipul graficului selectat
                string tip = ((ComboBoxItem)cmbTipGrafic.SelectedItem).Content.ToString();

                if (tip == "Linie")
                {
                    grafic.Series.Add(new LineSeries
                    {
                        Title = "Valori",
                        Values = new ChartValues<double>(valori)
                    });
                }
                else if (tip == "Bară")
                {
                    grafic.Series.Add(new ColumnSeries
                    {
                        Title = "Valori",
                        Values = new ChartValues<double>(valori)
                    });
                }
            }
            catch
            {
                MessageBox.Show("Introduceți doar numere separate prin virgulă!");
            }
        }
    }
}


